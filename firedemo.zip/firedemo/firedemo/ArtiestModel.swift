//
//  ArtiestModel.swift
//  firedemo
//
//  Created by TOPS on 6/13/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ArtiestModel: NSObject {

    var id: String?
    var name: String?
    var genre: String?
    
    init(id: String?, name: String?, genre: String?){
        self.id = id
        self.name = name
        self.genre = genre
    }
    
    
}
