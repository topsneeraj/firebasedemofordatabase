//
//  ViewController.swift
//  firedemo
//
//  Created by TOPS on 6/13/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var txtusername: UITextField!
    
    @IBOutlet weak var txt2: UITextField!
     var artistList = [ArtiestModel]()
    var refArtists: DatabaseReference!
 
    @IBOutlet weak var lblmsg: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
        refArtists = Database.database().reference().child("artists");
        
        getdata();
        
    }

    @IBAction func btnclick(_ sender: Any) {
        
       
        insertarties();
         getdata();
        
    }
    
    func insertarties() {
        
        
        
        let key = refArtists.childByAutoId().key
        
        //creating artist with the given values
        let artist = ["id":key,
                      "artistName": txtusername.text! as String,
                      "artistGenre": txt2.text! as String
        ]
        
        //adding the artist inside the generated unique key
        refArtists.child(key).setValue(artist);
        
        //displaying message
        lblmsg.text = "Artist Added"
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return artistList.count
    }
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        //creating a cell using the custom class
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        //the artist object
        let artist: ArtiestModel
        
        //getting the artist of selected position
        artist = artistList[indexPath.row]
        
        //adding values to labels
        cell.textLabel?.text = artist.name
        cell.detailTextLabel?.text = artist.genre
        
        //returning cell
        return cell
    }
    
    func getdata(){
    
        refArtists.observe(DataEventType.value, with: { (snapshot) in
            
            //if the reference have some values
            if snapshot.childrenCount > 0 {
                
                //clearing the list
                self.artistList.removeAll()
                
                //iterating through all the values
                for artists in snapshot.children.allObjects as! [DataSnapshot] {
                    //getting values
                    let artistObject = artists.value as? [String: AnyObject]
                    let artistName  = artistObject?["artistName"]
                    let artistId  = artistObject?["id"]
                    let artistGenre = artistObject?["artistGenre"]
                    
                    //creating artist object with model and fetched values
                    let artist = ArtiestModel(id: artistId as! String?, name: artistName as! String?, genre: artistGenre as! String?)
                    
                    //appending it to list
                    self.artistList.append(artist)
                }
                
                //reloading the tableview
                self.tbl.reloadData()
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

